origins = ["http://localhost"]

prefix_v1 = "/api/v1"

tags_metadata = [
    {
        "name": "User",
        "description": "Operations related to users.",
    }
]
