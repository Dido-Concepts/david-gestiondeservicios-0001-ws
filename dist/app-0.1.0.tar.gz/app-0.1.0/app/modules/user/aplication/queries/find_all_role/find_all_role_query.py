from pydantic import BaseModel


class FindAllRoleQuery(BaseModel):
    pass
