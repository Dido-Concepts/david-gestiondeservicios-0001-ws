from enum import Enum


class Status(Enum):
    ACTIVE = "Active"
    INACTIVE = "Inactive"
